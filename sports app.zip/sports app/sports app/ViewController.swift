//
//  ViewController.swift
//  sports app
//
//  Created by Macintosh on 19/06/2022.
//

import UIKit

class HomeViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

